﻿Imports System.Data.OleDb
Public Class Account_Registration
    Dim myCon As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\USER\Desktop\Group7Project\bin\Debug\UenrClinicdb.accdb")
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Close()
        Form1.Show()
        txtUserName.Clear()
        txtPassoword.Clear()
        txtPhone.Clear()
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        txtUserName.Clear()
        txtPassoword.Clear()
        txtPhone.Clear()
    End Sub

    Private Sub btnRegister_Click(sender As Object, e As EventArgs) Handles btnRegister.Click
        myCon.Open()
        Dim mycmd As New OleDbCommand("INSERT INTO EmployeeLogin_Account(UserName, [Password], Phone) Values('" & txtUserName.Text & "','" & txtPassoword.Text & "','" & txtPhone.Text & "')", myCon)

        Try
            mycmd.ExecuteNonQuery()
            myCon.Close()
            txtUserName.Clear()
            txtPassoword.Clear()
            txtPhone.Clear()
            MessageBox.Show("Account Registere Sucessfully!")
        Catch ex As Exception
            MsgBox(ex.Message)

        End Try

    End Sub

    Private Sub txtPhone_TextChanged(sender As Object, e As EventArgs) Handles txtPhone.TextChanged

    End Sub
End Class