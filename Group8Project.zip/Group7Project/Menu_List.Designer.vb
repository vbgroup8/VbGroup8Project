﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Menu_List
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.btnReceptionist = New System.Windows.Forms.Button()
        Me.btnNurse = New System.Windows.Forms.Button()
        Me.btnPharmacist = New System.Windows.Forms.Button()
        Me.btnDoctor = New System.Windows.Forms.Button()
        Me.btnManager = New System.Windows.Forms.Button()
        Me.btnAccountant = New System.Windows.Forms.Button()
        Me.btnLogOut = New System.Windows.Forms.Button()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.White
        Me.Label3.Font = New System.Drawing.Font("Tahoma", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(60, 9)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(304, 25)
        Me.Label3.TabIndex = 18
        Me.Label3.Text = "WELCOME TO UENR CLINIC"
        '
        'btnReceptionist
        '
        Me.btnReceptionist.BackColor = System.Drawing.Color.White
        Me.btnReceptionist.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnReceptionist.Location = New System.Drawing.Point(29, 65)
        Me.btnReceptionist.Name = "btnReceptionist"
        Me.btnReceptionist.Size = New System.Drawing.Size(165, 41)
        Me.btnReceptionist.TabIndex = 19
        Me.btnReceptionist.Text = "Receptionist"
        Me.btnReceptionist.UseVisualStyleBackColor = False
        '
        'btnNurse
        '
        Me.btnNurse.BackColor = System.Drawing.Color.White
        Me.btnNurse.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnNurse.Location = New System.Drawing.Point(29, 112)
        Me.btnNurse.Name = "btnNurse"
        Me.btnNurse.Size = New System.Drawing.Size(165, 41)
        Me.btnNurse.TabIndex = 20
        Me.btnNurse.Text = "Nurse"
        Me.btnNurse.UseVisualStyleBackColor = False
        '
        'btnPharmacist
        '
        Me.btnPharmacist.BackColor = System.Drawing.Color.White
        Me.btnPharmacist.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnPharmacist.Location = New System.Drawing.Point(221, 65)
        Me.btnPharmacist.Name = "btnPharmacist"
        Me.btnPharmacist.Size = New System.Drawing.Size(165, 41)
        Me.btnPharmacist.TabIndex = 22
        Me.btnPharmacist.Text = "Pharmacist"
        Me.btnPharmacist.UseVisualStyleBackColor = False
        '
        'btnDoctor
        '
        Me.btnDoctor.BackColor = System.Drawing.Color.White
        Me.btnDoctor.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDoctor.Location = New System.Drawing.Point(29, 159)
        Me.btnDoctor.Name = "btnDoctor"
        Me.btnDoctor.Size = New System.Drawing.Size(165, 41)
        Me.btnDoctor.TabIndex = 21
        Me.btnDoctor.Text = "Doctor"
        Me.btnDoctor.UseVisualStyleBackColor = False
        '
        'btnManager
        '
        Me.btnManager.BackColor = System.Drawing.Color.White
        Me.btnManager.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnManager.Location = New System.Drawing.Point(221, 159)
        Me.btnManager.Name = "btnManager"
        Me.btnManager.Size = New System.Drawing.Size(165, 41)
        Me.btnManager.TabIndex = 24
        Me.btnManager.Text = "Manager"
        Me.btnManager.UseVisualStyleBackColor = False
        '
        'btnAccountant
        '
        Me.btnAccountant.BackColor = System.Drawing.Color.White
        Me.btnAccountant.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAccountant.Location = New System.Drawing.Point(221, 112)
        Me.btnAccountant.Name = "btnAccountant"
        Me.btnAccountant.Size = New System.Drawing.Size(165, 41)
        Me.btnAccountant.TabIndex = 23
        Me.btnAccountant.Text = "Accountant"
        Me.btnAccountant.UseVisualStyleBackColor = False
        '
        'btnLogOut
        '
        Me.btnLogOut.BackColor = System.Drawing.Color.Yellow
        Me.btnLogOut.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnLogOut.Location = New System.Drawing.Point(221, 223)
        Me.btnLogOut.Name = "btnLogOut"
        Me.btnLogOut.Size = New System.Drawing.Size(165, 41)
        Me.btnLogOut.TabIndex = 26
        Me.btnLogOut.Text = "LOG OUT"
        Me.btnLogOut.UseVisualStyleBackColor = False
        '
        'btnClose
        '
        Me.btnClose.BackColor = System.Drawing.Color.Red
        Me.btnClose.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClose.Location = New System.Drawing.Point(29, 223)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(165, 41)
        Me.btnClose.TabIndex = 25
        Me.btnClose.Text = "CLOSE"
        Me.btnClose.UseVisualStyleBackColor = False
        '
        'Menu_List
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.Group7Project.My.Resources.Resources._726693cf83094cf1cb60e2a107880531
        Me.ClientSize = New System.Drawing.Size(425, 283)
        Me.Controls.Add(Me.btnLogOut)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.btnManager)
        Me.Controls.Add(Me.btnAccountant)
        Me.Controls.Add(Me.btnPharmacist)
        Me.Controls.Add(Me.btnDoctor)
        Me.Controls.Add(Me.btnNurse)
        Me.Controls.Add(Me.btnReceptionist)
        Me.Controls.Add(Me.Label3)
        Me.Name = "Menu_List"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Menu_List"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label3 As Label
    Friend WithEvents btnReceptionist As Button
    Friend WithEvents btnNurse As Button
    Friend WithEvents btnPharmacist As Button
    Friend WithEvents btnDoctor As Button
    Friend WithEvents btnManager As Button
    Friend WithEvents btnAccountant As Button
    Friend WithEvents btnLogOut As Button
    Friend WithEvents btnClose As Button
End Class
