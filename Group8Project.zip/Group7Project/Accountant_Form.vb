﻿Public Class Accountant_Form
    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()
        Menu_List.Show()
    End Sub

    Private Sub btnLogOut_Click(sender As Object, e As EventArgs) Handles btnLogOut.Click
        Me.Hide()
        Form1.Show()
    End Sub

    Private Sub btnReviewPayment_Click(sender As Object, e As EventArgs) Handles btnReviewPayment.Click
        Me.Hide()
        Patient_Payment.Show()
    End Sub

    Private Sub btnAssignPresc_Click(sender As Object, e As EventArgs) Handles btnAssignPresc.Click
        Me.Hide()
        Employees_Form.Show()
    End Sub
End Class