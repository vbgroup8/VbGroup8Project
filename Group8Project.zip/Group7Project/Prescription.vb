﻿Imports System.Data.OleDb
Public Class Prescription
    Dim myCon As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\USER\Desktop\Group7Project\bin\Debug\UenrClinicdb.accdb")
    Dim myCmd As OleDbCommand
    Dim myAdapter As OleDbDataAdapter
    Dim mDT As DataTable

    Private Sub Prescription_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'UenrClinicdbDataSet.Prescription' table. You can move, or remove it, as needed.
        Me.PrescriptionTableAdapter.Fill(Me.UenrClinicdbDataSet.Prescription)

        ' Create OleDbCommand and OleDbDataAdapter objects
        myCmd = New OleDbCommand("SELECT * FROM Prescription", myCon)
        myAdapter = New OleDbDataAdapter(myCmd)

        ' Create OleDbCommandBuilder object to generate updateable queries
        Dim builder As New OleDbCommandBuilder(myAdapter)
        myAdapter.UpdateCommand = builder.GetUpdateCommand()
        myAdapter.InsertCommand = builder.GetInsertCommand()
        myAdapter.DeleteCommand = builder.GetDeleteCommand()

        ' Add this line to add a new row
        Dim cmdInsert As OleDbCommand = builder.GetInsertCommand()
        cmdInsert.CommandText = cmdInsert.CommandText.Replace("?", "VALUES (?,?,?,?,?,?,?,)")
    End Sub



    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        Try
            PrescriptionBindingSource.EndEdit()
            myAdapter.Update(UenrClinicdbDataSet.Prescription)
            MessageBox.Show("Successfully Saved")
            txtPatient_ID.Clear()
            txtFirstName.Clear()
            txtLastName.Clear()
            txtAge.Clear()
            txtGender.Clear()
            txtPrescription.Clear()
            txtNurseDoctor.Clear()
        Catch ex As Exception
            MessageBox.Show("An error occurred: " & ex.Message)
        End Try
    End Sub

    Private Sub btnAddNew_Click(sender As Object, e As EventArgs) Handles btnAddNew.Click
        PrescriptionBindingSource.AddNew()
    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        PrescriptionBindingSource.RemoveCurrent()
    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()
        Menu_List.Show()
    End Sub

    Private Sub btnPrevious_Click(sender As Object, e As EventArgs) Handles btnPrevious.Click
        PrescriptionBindingSource.MovePrevious()
    End Sub

    Private Sub btnNext_Click(sender As Object, e As EventArgs) Handles btnNext.Click
        PrescriptionBindingSource.MoveNext()
    End Sub

    Private Sub btnSearch_Click(sender As Object, e As EventArgs) Handles btnSearch.Click

    End Sub
End Class
