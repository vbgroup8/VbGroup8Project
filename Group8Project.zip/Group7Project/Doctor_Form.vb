﻿Public Class Doctor_Form
    Private Sub btnReviewPatient_Click(sender As Object, e As EventArgs) Handles btnReviewPatient.Click
        Me.Hide()
        Patient_Registration.Show()
    End Sub

    Private Sub btnAssignPresc_Click(sender As Object, e As EventArgs) Handles btnAssignPresc.Click
        Me.Hide()
        Prescription.Show()
    End Sub

    Private Sub btnReviewPayment_Click(sender As Object, e As EventArgs) Handles btnReviewPayment.Click
        Me.Hide()
        Patient_Payment.Show()
    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()
        Nurse_Confirmation.Show()
    End Sub

    Private Sub btnLogOut_Click(sender As Object, e As EventArgs) Handles btnLogOut.Click
        Me.Hide()
        Form1.Show()
    End Sub
End Class