﻿Imports System.Data.OleDb
Public Class Doctor_Confirmation
    Dim myCon As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\USER\Desktop\Group7Project\bin\Debug\UenrClinicdb.accdb")

    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click
        Try
            myCon.Open()
            Dim mycmd As New OleDbCommand("SELECT * FROM Employee_List WHERE FirstName = @FirstName AND LastName = @LastName AND Employee_ID = @Employee_ID AND JobType = 'DOCTOR'", myCon)

            mycmd.Parameters.AddWithValue("@FirstName", txtFirstName.Text)
            mycmd.Parameters.AddWithValue("@LastName", txtLastName.Text)
            mycmd.Parameters.AddWithValue("@Employee_ID", txtDoctor_ID.Text)

            Dim myread As OleDbDataReader = mycmd.ExecuteReader

            If myread.Read Then
                MessageBox.Show("Login Successfully!")
                txtFirstName.Clear()
                txtLastName.Clear()
                txtDoctor_ID.Clear()
                Me.Hide()
                Doctor_Form.Show()
            Else
                MessageBox.Show("Invalid UserName or Password!. Check and Try Again!")
            End If

            myread.Close()
            myCon.Close()
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        txtFirstName.Clear()
        txtLastName.Clear()
        txtDoctor_ID.Clear()
    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()
        Menu_List.Show()
    End Sub
End Class