﻿Imports System.Data.OleDb
Imports System.Drawing.Printing



Public Class Employees_Form
    Dim myCon As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\USER\Desktop\Group7Project\bin\Debug\UenrClinicdb.accdb")

    Private Sub Employees_Form_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'UenrClinicdbDataSet.Employee_List' table. You can move, or remove it, as needed.
        Me.Employee_ListTableAdapter.Fill(Me.UenrClinicdbDataSet.Employee_List)
    End Sub

    Private Sub btnNext_Click(sender As Object, e As EventArgs) Handles btnNext.Click
        EmployeeListBindingSource.MoveNext()
    End Sub

    Private Sub btnPrevious_Click(sender As Object, e As EventArgs) Handles btnPrevious.Click
        EmployeeListBindingSource.MovePrevious()
    End Sub

    Private Sub btnLogout_Click(sender As Object, e As EventArgs) Handles btnLogout.Click
        Me.Hide()
        Form1.Show()
    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()
        Accountant_Form.Show()
    End Sub

    Private Sub btnPrint_Click(sender As Object, e As EventArgs) Handles btnPrint.Click
        Dim printDialog As New PrintDialog
        Dim printPreviewDialog As New PrintPreviewDialog
        Dim printDocument As New PrintDocument

        AddHandler printDocument.PrintPage, AddressOf printDocument_PrintPage

        printDialog.Document = printDocument
        printPreviewDialog.Document = printDocument

        If printDialog.ShowDialog = DialogResult.OK Then
            printDocument.Print()
        Else
            printPreviewDialog.ShowDialog()
        End If
    End Sub

    Private Sub printDocument_PrintPage(sender As Object, e As PrintPageEventArgs)
        Dim dgv As DataGridView = DataGridView1
        Dim bmp As New Bitmap(dgv.Width, dgv.Height)
        dgv.DrawToBitmap(bmp, New Rectangle(0, 0, dgv.Width, dgv.Height))
        e.Graphics.DrawImage(bmp, 0, 0)
    End Sub
End Class


